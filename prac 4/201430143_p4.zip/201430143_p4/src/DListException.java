
public class DListException extends RuntimeException {
	
	private static final long serialVersionUID = 1L;
    public DListException() {
        super();
    }
    
    public DListException(String message) {
        super(message);
    }
    
    public DListException(String message, Throwable cause) {
        super(message, cause);
    }
    
    public DListException(Throwable cause) {
        super(cause);
    } 
	
}
