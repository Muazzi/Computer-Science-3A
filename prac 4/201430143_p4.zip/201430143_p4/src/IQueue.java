
public interface IQueue<T> {
	/**
	 * @param m
	 */
	public void enqueue(T m);
	/**
	 * @return the removed element
	 * @throws QueueEmptyException
	 */
	public T dequeue() throws QueueEmptyException;
	/**
	 * @return returns the front element in the queue
	 * @throws QueueEmptyException
	 */
	public T front() throws QueueEmptyException;
	
	/**
	 * @return the size of the queue
	 */
	public int size();
	/**
	 * @return whether the queue is empty or not
	 */
	public boolean isEmpty();
}
