
public class Queue<T> implements IQueue<T> {
	private DList<T> queue;
	private int size;
	private Node<T> front;
	
	/**
	 * The default constructor
	 */
	public Queue() {
		queue = new DList<>();
		size = 0;
	}
	
	//3 marks
	/* (non-Javadoc)
	 * @see IQueue#enqueue(java.lang.Object)
	 */
	@Override
	public void enqueue(T m) {
		//TODO: Complete
		queue.addLast(m);
		size++;
			
		
	}
	
	//4 marks
	/* (non-Javadoc)
	 * @see IQueue#dequeue()
	 */
	@Override
	public T dequeue() throws QueueEmptyException {
		//TODO: Complete
		this.front();
		
      size--; 
      return front.getElement();
			
	}

	//3 marks
	/* (non-Javadoc)
	 * @see IQueue#front()
	 */
	@Override
	public T front() throws QueueEmptyException {
		//TODO: Complete
		front = queue.front(); 
		return  front();
		

		
		
	}

	/* (non-Javadoc)
	 * @see IQueue#size()
	 */
	@Override
	public int size() {
		return size;
	}

	/* (non-Javadoc)
	 * @see IQueue#isEmpty()
	 */
	@Override
	public boolean isEmpty() {
		return size == 0;
	}
}
