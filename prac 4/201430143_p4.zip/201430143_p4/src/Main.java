
public class Main {
	//15marks
	/**
	 * @param tasks
	 * @param interns
	 */
	public static void allocateInternsWithQueue(Queue<Task> tasks,Queue<Intern> interns){
		//TODO: Complete
		double  completed;
		Intern intern;
		
		Task iTask;
		for (int i = 0 ; i<9;i++)
		{
			 try {
				intern = 	interns.dequeue();
				
				for (int k=0;k<9 ;k++)
				{
					iTask =  tasks.dequeue();
					if (intern.getEnergy()!=0)
					{
						
						int work =  iTask.getWorkTotal();
						iTask.setWorkTotal(iTask.getWorkTotal()- intern.getWorkRate());
						intern.setEnergy(intern.getEnergy()-intern.getWorkRate());
						completed=(iTask.getWorkTotal()/work)*100;
						System.out.println(intern.toString()+work);
						
					}
					else
					{
						System.out.println("the interns are tired");
					}
				}
			} catch (QueueEmptyException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}  
		
		
		
		
	
	  
		
			
		
		
			
	
		     
	
		
	
	   
			
		}
		
		
		
		
			
			
	
		  
	  
	  
	
	//15 marks
	/**
	 * @param tasks
	 * @param interns
	 */
	public static void allocateInternsRandomly(Queue<Task> tasks,Intern[] interns){
		//TODO: Complete
		
		while (!tasks.isEmpty())
		{
			try {
				Task  task =  tasks.dequeue();
			} catch (QueueEmptyException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
			
		}
	}
	
	/**
	 * 10 marks for compilation and correct execution
	 * @param args
	 */
	public static void main(String[] args) {
		Queue<Task> tasks = new Queue<Task>();		
		Intern[] interns = new Intern[10]; 
		Queue<Intern> internQ = new Queue<Intern>();
		
		for(int i=0;i< 10;i++){
			interns[i] = new Intern();
			interns[i].setName("Intern "+i);
			System.out.println(interns[i]);
			internQ.enqueue(interns[i]);
		}
		
		for(int j=0;j<10;j++){
			Task task = new Task();
			task.setName("Task "+j);
			System.out.println(task);
			tasks.enqueue(task);
		}
		
		allocateInternsRandomly(tasks, interns);
		allocateInternsWithQueue(tasks, internQ);	
		
	}

}
