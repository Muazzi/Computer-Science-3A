/*
 * The PolyLine class used for storing multiple lines in a stroke
 */
public class PolyLine{
	private  ArrayList<Coordinate> coordinates;
	
	/*
	 * Default constructor
	 */
	public PolyLine(){
		coordinates = new ArrayList<Coordinate>();;
		
	}
	
	/*
	 * The clone method for returning a copy of the current instance	 * 
	 */
	public PolyLine clone(){
		PolyLine temp = new PolyLine();		
		
		for(int i=0;i<getSize();i++){
			Coordinate c = getCoordinate(i);
			temp.addCoordinate(c.getX(),c.getY());
		}
		return temp;
	}
	
	/**
	 * @param index
	 * @return
	 */
	public Coordinate getCoordinate(int index){
		return coordinates.get(index);
	}
	
	/**
	 * @param index
	 * @param c
	 */
	public void setCoordinate(int index, Coordinate c){
		coordinates.set(index, c);
	}
	
	/*
	 * Adds a new Coordinate to the coordinate arrayList that form part of a stroke
	 */
	public void addCoordinate(int x, int y){
		
			coordinates.add(coordinates.size(), new Coordinate(x, y));		
	}
	/*
	 * Returns the amount of coordinates in the stroke
	 */
	public int getSize(){
		return coordinates.size();
	}
	
	/*
	 * The overridden toString method for a String-based representation of 
	 * a Coordinate
	 */
	@Override
	public String toString(){
		String s = "";
		for(int i=0;i<coordinates.size();i++){
			Coordinate c = coordinates.get(i);
			s+="("+c.getX()+","+c.getY()+")";
		}
		return s;
	}	
}
