import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import javax.swing.JPanel;

@SuppressWarnings("serial")
public class SurfacePanel extends JPanel implements MouseMotionListener, MouseListener{
	private ArrayList<PolyLine> renderList;	
	private PolyLine currentLine;
	
	/*
	 * The default constructor
	 */
	public SurfacePanel(){		
		renderList = new ArrayList<PolyLine>();
		currentLine =  new PolyLine();
		
	}
	
	
	/*
	 * The overridden paintComponent method for rendering the current lines 
	 * ********** 8 marks ****************************
	 */
	public void paintComponent(Graphics g){		
		//TODO: Complete	
		super.paintComponent(g);
		g.setColor(Color.RED);
		  for (int i =0 ; i<renderList.size();i++)
			  currentLine = renderList.get(i);
		for (int  j =0 ; j<currentLine.getSize();j++)
		{
			g.drawLine(currentLine.getCoordinate(j).getX(), currentLine.getCoordinate(j).getY(), currentLine.getCoordinate(j++).getX(), currentLine.getCoordinate(j++).getY());
		}
		
	}
	
	/*
	 * The overridden mouseDragged handler to add coordinates for rendering
	 * 
	 */
	@Override
	public void mouseDragged(MouseEvent arg0) {		
		System.out.println("Mouse dragged "+ arg0.getX()+" "+arg0.getY());
		currentLine.addCoordinate(arg0.getX(),arg0.getY());	
	
		repaint();
	}
	/*
	 * The mouse released method that indicates the end of a stroke
	 * ********** 2 marks ****************************
	 */
	@Override
	public void mouseReleased(MouseEvent e) {
		//TODO: Complete
		currentLine = null ; 
		renderList=null;
		
		System.out.println("End of stroke");
		repaint();
	}
	
	@Override
	public void mouseMoved(MouseEvent arg0) {}

	@Override
	public void mouseClicked(MouseEvent e) {}

	@Override
	public void mouseEntered(MouseEvent e) {}

	@Override
	public void mouseExited(MouseEvent e) {}

	@Override
	public void mousePressed(MouseEvent e) {}
	
}
