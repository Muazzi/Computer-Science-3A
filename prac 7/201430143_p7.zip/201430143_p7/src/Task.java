import java.util.Random;

public class Task {
	private Random r;
	private int workCompleted;
	private int workTotal;
	private String name;	
	
	public Task(){
		r = new Random();
		workCompleted = 0;
		workTotal = r.nextInt(100);
	}
	
	/**
	 * @return the percentageCompleted
	 */
	public int getWorkCompleted() {
		return workCompleted;
	}
	/**
	 * @param percentageCompleted the percentageCompleted to set
	 */
	public void setWorkCompleted(int percentageCompleted) {
		this.workCompleted = percentageCompleted;
	}
	
	/**
	 * @return the workTotal
	 */
	public int getWorkTotal() {
		return workTotal;
	}

	/**
	 * @param workTotal the workTotal to set
	 */
	public void setWorkTotal(int workTotal) {
		this.workTotal = workTotal;
	}
	
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	
	public String toString(){
		return "Name: "+name+" work: "+workCompleted+ " of: "+workTotal;
	}

	
}
