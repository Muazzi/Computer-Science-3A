import java.util.Random;

public class Intern {
	private Random r;
	private String name;
	private int workRate;
	private int energy;
	
	public Intern(){
		r = new Random();
		workRate = r.nextInt(20);
		energy = 100;
	}
	
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * @return the workRate
	 */
	public int getWorkRate() {
		return workRate;
	}
	/**
	 * @param workRate the workRate to set
	 */
	public void setWorkRate(int workRate) {
		this.workRate = workRate;
	}
	/**
	 * @return the energy
	 */
	public int getEnergy() {
		return energy;
	}
	/**
	 * @param energy the energy to set
	 */
	public void setEnergy(int energy) {
		this.energy = energy;
	}
	
	public String toString(){
		return "Name: "+name+" WR: "+workRate+" Energy: "+energy;
	}
}
