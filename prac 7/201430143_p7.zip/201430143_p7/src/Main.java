//Correctness 10 marks ***********************************************
import java.util.Random;


public class Main {	
	private static final int PROCESS_NO = 10;
	
	/**
	 * Method that allocates tasks based on priority
	 * @param tasks
	 * @param interns
	 * 10 marks ***********************************************
	 */
	public static void allocateInternsWithPriorityQueue(PriorityQueue<Integer, Task> tasks, Intern[] interns){
	//TODO:Complete code
		int counter = 0;
		while(!tasks.isEmpty())
		{
			Entry<Integer,Task> cur =    tasks.removeMin();
			
			while(cur.getValue().getWorkCompleted()<cur.getValue().getWorkTotal())
			{
				int  completed=0 ; 
				for(int i =0 ; i<interns.length;i++)
				{
					while(interns[i].getEnergy()>0)
					{
						interns[i].setEnergy(interns[i].getEnergy()-interns[i].getWorkRate());
						completed+=interns[i].getWorkRate();
						cur.getValue().setWorkCompleted(completed);
						
					}
					if(interns[i].getWorkRate()==100)
					{
						break;
					}
					System.out.println("Task "+counter+"at"+completed+"%");
				}
			}
			counter++;
		}
	}
	
	public static void main(String[] args) {
		System.out.println("Heap-Based Priority Queue Intern Scheduler");
		System.out.println("==============================================");
		Random rand = new Random(System.currentTimeMillis());
		
		PriorityQueue<Integer, Task> taskQ = new PriorityQueue<Integer, Task>();		 
		Intern[] interns = new Intern[10]; 
		
		for(int i=0;i< 10;i++){
			interns[i] = new Intern();
			interns[i].setName("Intern "+i);
			System.out.println(interns[i]);
		}
		
		for(int j=0;j<10;j++){
			Task task = new Task();
			task.setName("Task "+j);
			System.out.println(task);
			taskQ.insert(new Entry<Integer, Task>(rand.nextInt(10),task));
		}
				
		allocateInternsWithPriorityQueue(taskQ, interns);			
	}
}