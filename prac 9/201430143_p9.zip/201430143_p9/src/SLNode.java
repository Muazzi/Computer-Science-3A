
/**
 * A Skiplist Node
 * @param <E> The type of this node
 */
public class SLNode<E> implements Position<E> {

    SLNode<E> next, prev, above, below;
    E element;
    
    /**
     * Construct a new SLNode
     * @param next the next link
     * @param prev the prev link
     * @param above the above link
     * @param below the below link
     * @param element the element
     */
    public SLNode(SLNode<E> next, SLNode<E> prev, SLNode<E> above, SLNode<E> below, E element) {
        this.next = next;
        this.prev = prev;
        this.above = above;
        this.below = below;
        this.element = element;
    }

    /**
     * Get the element for this Node
     * @return The element in this node
     */
    public E element() {
        if ((next == null) && (prev == null)) {
            throw new InvalidPositionException("Position not valid");
        }
        return element;
    }

    /*Accessor Methods */
    public SLNode<E> getNext() {
        return next;
    }

    public SLNode<E> getPrev() {
        return prev;
    }

    public SLNode<E> getBelow() {
        return below;
    }

    public SLNode<E> getAbove() {
        return above;
    }

    /*Update Methods*/
    public void setNext(SLNode<E> next) {
        this.next = next;
    }

    public void setPrev(SLNode<E> prev) {
        this.prev = prev;
    }

    public void setBelow(SLNode<E> below) {
        this.below = below;
    }

    public void setAbove(SLNode<E> above) {
        this.above = above;
    }

}
