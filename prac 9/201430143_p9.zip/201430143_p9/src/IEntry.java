
public interface IEntry<K,V> {

  public K getKey();

  public V getValue();
}

