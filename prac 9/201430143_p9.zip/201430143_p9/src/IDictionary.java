import java.util.Iterator;

public interface IDictionary<K,V> {

  public int size();
  public boolean isEmpty();
  public IEntry<K,V> find(K key)
    throws InvalidKeyException;
  public Iterable<IEntry<K,V>> findAll(K key)
    throws InvalidKeyException;
  public IEntry<K,V> insert(K key, V value)
    throws InvalidKeyException;
  public IEntry<K,V> remove(IEntry<K, V> e)
    throws InvalidEntryException;
  public Iterator<IEntry<K,V>> entries();
}

