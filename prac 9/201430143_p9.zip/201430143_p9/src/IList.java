
public interface IList<T> extends Iterable<T> {
	Position<T> addAfter(Position<T> p, T item);
	Position<T> addBefore(Position<T> p, T item);
	Position<T> addFirst(T item);
	Position<T> addLast(T item);
	T remove(Position<T> p);
	Position<T> search(T p);
	
	Position<T> next(Position<T> p);
	Position<T> prev(Position<T> p);
	Position<T> first();
	Position<T> last();
	
	boolean isEmpty();
	Integer size();
}
