import java.util.Scanner;

//Overall correctness: 15 marks **********************************************************************
//Overall for Main class: 10 marks *******************************************************************
public class Main {
	
	public static void main(String[] args) {		
		
		BTNode<String> rootNode = new BTNode<String>(null, null, null, "Being a programmer is the best job in the world (T/F).");		
		
		BTNode<String> leftParentNode = new BTNode<String>(rootNode, null, null, "Java is your language of choice (T/F)");
		rootNode.setLeft(leftParentNode);
		
		BTNode<String> leftKidNode1 = new BTNode<String>(leftParentNode, null, null, "O(NlogN) is the worst case computational complexity for merge sort(T/F).");
		leftParentNode.setLeft(leftKidNode1);		
		
		BTNode<String> rightGrandKidNode1 = new BTNode<String>(leftKidNode1, null, null, "Almost there, but sorry :\\ ");
		leftKidNode1.setRight(rightGrandKidNode1);
		
		BTNode<String> rightKidNode1 = new BTNode<String>(leftParentNode, null, null, "O(logn) is the worst case computational complexity for the fibonacci (T/F).");
		leftParentNode.setRight(rightKidNode1);
		
		BTNode<String> leftGrandKidNode2 = new BTNode<String>(leftKidNode1, null, null, "No.");
		rightKidNode1.setLeft(leftGrandKidNode2);
		
		BTNode<String> rightGrandKidNode2 = new BTNode<String>(leftKidNode1, null, null, "Congratulations, you qualify for the next interview.");
		rightKidNode1.setRight(rightGrandKidNode2);
		
		BTNode<String> rightParentNode = new BTNode<String>(rootNode, null, null, "(T || F) && (F || F)");
		rootNode.setRight(rightParentNode);
		
		BTNode<String> leftKidNode2 = new BTNode<String>(rightParentNode, null, null, "This job is not for you.");
		rightParentNode.setLeft(leftKidNode2);
		
		BTNode<String> rightKidNode2 = new BTNode<String>(rightParentNode, null, null, "You pass, you should receive an email for the next interview.");
		rightParentNode.setRight(rightKidNode2);						
		
		
		BinaryTree<String> bt = new BinaryTree<String>(rootNode);
		
		System.out.println("Pre-order traversal test:");
		PositionList<String> out = new PositionList<String>();
		bt.PreorderElementTraversal(out, bt.root());		
		System.out.println(out);
		System.out.println("");
		
		System.out.println("In-order traversal test:");
		out = new PositionList<String>();
		bt.InorderElementTraversal(out, bt.root());		
		System.out.println(out);
		System.out.println("");
		
		System.out.println("Post-order traversal test:");
		out = new PositionList<String>();
		bt.PostOrderElementTraversal(out, bt.root());		
		System.out.println(out);
		System.out.println("");
					
		System.out.println("==============================================");
		System.out.println("			Starting Job Interview Program");
		System.out.println("==============================================");
		System.out.println("");
		
		/*
		 * Using the built decision tree ask the user and provide the appropriate answers, 
		 * so that they may be able to determine how their date is going to go and terminate
		 * once a final answer is given. 
		 */
		//10 marks ***********************************************************************************
		//TODO: Complete
		

		BTPosition<String> currentNode = bt.root(); 
		System.out.println(currentNode.element());
		Scanner sc = new Scanner(System.in);
		String answer = "";
		while(currentNode.left()!= null || currentNode.right() != null){
			answer = sc.nextLine();
			if(answer.equals("T")){
				currentNode = currentNode.left();
				System.out.println(currentNode.element());
			}
			if(answer.equals("F")){
				currentNode = currentNode.right();
				System.out.println(currentNode.element());
			}
			
		}
		
		
	}
	
}
